Przy testowaniu działania wykresu, zalecam generowanie go dla jednego z tych miast:
-Torń
-Kair
-Bydgoszcz
ze względu na to, iż w bazie znajduję sie najwięcej wpisów z tych właśnie miast