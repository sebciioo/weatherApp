function goToIndex() {
            window.location.href = '/';
}

function goToHistory() {
            window.location.href = '/history';
}


