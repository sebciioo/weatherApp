class Config:
    SECRET_KEY = 'programowanieIII'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///weather.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WEATHER_API_KEY = '7ef52c6a2b6248e2417e4c49386ea14d'
